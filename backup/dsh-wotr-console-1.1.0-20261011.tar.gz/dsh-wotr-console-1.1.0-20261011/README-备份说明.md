# dsh-wotr-console 自包含备份（1.1.0 / 2026-10-11）

这是 `dsh-wotr-console` 插件的**整份快照**：把这个目录（或同级的
`dsh-wotr-console-1.1.0-20261011.tar.gz`）拿到任何一台机器上都能直接用，
不需要 git、不需要联网克隆仓库。

## 里面有什么

| 路径 | 说明 |
|---|---|
| `dsh-wotr-console/` | 插件本体（63 个文件）：三个 Loader 入口、浏览器端管理页、vendor 池、单测 |
| `package.json` | 仓库根的**安装壳**：`name` 是 `dsh-wotr-console`，`dsh.bundle.patch` 指向 `./dsh-wotr-console/cordis.patch.yml` —— 插件管理页靠这个字段把它认成组合包 |
| `README.md` | 仓库根说明（安装 / 排错 / provider 清单 / 验证命令） |
| `MANIFEST.txt` | 全部文件的 sha256 与字节数（校验用，末尾有统计） |

快照内容与仓库 `main` 分支逐字节一致（生成时用 `diff -r` 核过）。

## 怎么用

**A. 走插件管理页（需要 git）** —— 推荐

把这份快照当仓库推到 GitHub（或在别的机器上 `git init` 后推上去），然后
设置 → 插件 → 安装 → 填 `github:<owner>/<repo>`。`package.json` 就在快照这一层，
所以管理页能识别出组合包；装完**整个退出重开 DSH**。

**B. 手工放进 profile（不需要 git）**

```sh
# 目标：~/.dsh/profiles/desktop/node_modules/dsh-wotr-console
cp -R dsh-wotr-console ~/.dsh/profiles/desktop/node_modules/dsh-wotr-console
```

再补两处（profile 的 `package.json`）：

- `dependencies` 里加 `"dsh-wotr-console": "link:<快照绝对路径>/dsh-wotr-console"`
- `dsh.profile.bundles` 里要有 `"dsh-wotr-console"`

profile 的 `cordis.patch.yml` 需要三个 Loader entry：`dsh-wotr-console`、
`dsh-wotr-console/trae`、`dsh-wotr-console/qoder`。**目标机器上若已有同名条目，
不要覆盖** —— 条目下面的 `config:` 就是账号与模型设置本身。

**C. 只在本机回滚**

```sh
rsync -a --delete dsh-wotr-console/ ~/.dsh/profiles/desktop/node_modules/dsh-wotr-console/
```

**装完必须整个退出重开 DSH**（ES module 有缓存），然后：

```sh
curl -s http://127.0.0.1:19387/plugins/dsh-wotr-console/qoder/models/refresh
# capabilities.imageAttachments 应为 true；模型选择器里应看到 5 个 provider：
# workbuddy-xdpool / workbuddy-xdpool-global / trae / trae-global / qoder
```

## 没包含什么（重要）

- **账号凭据**：`~/.dsh/plugin-data/dsh-wotr-console/`（号池、令牌、积分与历史记录）
  **不在**快照里。那是本机数据，也**不应该**进任何仓库。
- **profile 配置**：`~/.dsh/profiles/desktop/cordis.patch.yml` 里的 `config:`
  （浏览器登录方式、分配策略、模型勾选、区域开关等）是每台机器自己的设置，需要重配一次。
- **宿主内包**：`@deepseek-ai/*`、`@earendil-works/pi-ai` 等由 DSH 在运行时从安装目录
  路由给每个 profile（见根 README「宿主内包不用你管」），快照里没有、也不需要。
- 仓库里归档的旧插件（`dsh-workbuddy-console/`、`dsh-connect-trae/`）、`patches/`、
  `tools/`、`docs/` 都不在这个快照里 —— 这里只有这一个插件。

## 校验

```sh
cd dsh-wotr-console-1.1.0-20261011
# macOS：shasum；Linux：sha256sum
awk 'NF==3 && $1 ~ /^[0-9a-f]{64}$/ {print $1"  "$3}' MANIFEST.txt | shasum -a 256 -c -
# 压缩包本身的校验值在同级的 dsh-wotr-console-1.1.0-20261011.tar.gz.sha256
```

## 这份快照是怎么生成的

```sh
cd /Users/a1412/Desktop/dsh-workbuddy-mode
NAME=dsh-wotr-console-1.1.0-20261011
mkdir -p "backup/$NAME"
rsync -a --exclude node_modules --exclude .dsh-runtime-deps \
      dsh-wotr-console/ "backup/$NAME/dsh-wotr-console/"
cp -p package.json README.md "backup/$NAME/"
# MANIFEST.txt 由 node 递归算 sha256 生成，见文件末尾统计
tar -czf "backup/$NAME.tar.gz" -C backup "$NAME"
shasum -a 256 "backup/$NAME.tar.gz" > "backup/$NAME.tar.gz.sha256"
```
